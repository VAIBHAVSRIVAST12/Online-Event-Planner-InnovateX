document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.querySelector(".login-page");
    const errorMessages = document.getElementById("errorMessages");

    ḷoginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        // Retrieve the entered username and password
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        if(username, password){
          errorMessages.innerHTML = "Login successful!";
                    setTimeout(function() {
                        window.location.href = "loginhome.html";
                    }, 2000);

        }

            function showError(message) {
                errorMessages.innerHTML = message;
            }
});
